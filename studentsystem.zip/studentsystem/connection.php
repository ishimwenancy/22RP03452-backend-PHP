<?php
try{
$connection=mysqli_connect("localhost","root","","studentsystem");
}
catch(SQLException $e){
    echo $e->getMessage;

}
?>