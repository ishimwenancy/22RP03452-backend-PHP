<?php
include 'connection.php';

$student=$_GET['student_id'];
$query=mysqli_query($connection,"delete from addstudent where student_id='$student'");
header("location:display.php");
?>
