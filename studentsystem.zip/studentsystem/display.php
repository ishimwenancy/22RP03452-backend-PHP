<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border='1'>
        <tr>
            <td>user id</td>
            <td>firstname</td>
            <td>lastname</td>
            <td>age</td>
            <td>departement</td>
            <td>gender</td>
            <td>option</td>
            <td>update</td>
        </tr>
        <?php
        include 'connection.php';
        $query=mysqli_query($connection,"select * from addstudent");
        while($row=mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $row['student_id']?></td>
                <td><?php echo $row['firstname']?></td>
                <td><?php echo $row['lastname']?></td>
                <td><?php echo $row['age']?></td>
                <td><?php echo $row['department']?></td>
                <td><?php echo $row['gender']?></td>
                <td><a href="delete.php?student_id=<?php echo $row['student_id']?>">delete</a></td>
                <td><a href="update.php?student_id=<?php echo $row['student_id']?>">update</a></td>
                
            </tr>
            <?php
        }
        ?>
    </table>
</body>
</html>