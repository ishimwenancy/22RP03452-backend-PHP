<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Login form</h1>
    <form action="" method="post">

    <label for="username">Username</label><br>
    <input type="text" name="username"><br>
    <label for="password">password</label><br>
    <input type="text" name="password"><br>
    <input type="checkbox" name="remember">Remember me <br>
    <input type="submit" name="submit"><br>
    
    </form>
    
</body>
</html>
<?php
session_start();
if($_SERVER['REQUEST_METHOD']=='POST'){

    include 'connection.php';
    $names=$_POST['username'];
    $pass=$_POST['password'];

    if(!empty($names &&$pass)){

        $querry=mysqli_query($connection,"select * from users where username='$names'&& password='$pass'");
        $num=mysqli_num_rows($querry);
        if($num){
            $_SESSION['user']=$names;
            echo "<script>alert('welcome $names'),location='dashboard.php'</script>";
        }else{
            echo "<script>alert('impossible')</script>";
        }

    }else{
        echo "must be filled";
    }
}
?>