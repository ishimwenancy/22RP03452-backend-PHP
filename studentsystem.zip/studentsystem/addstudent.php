<?php
include 'dashboard.php';
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <label for="firstname">firstname</label><br>
        <input type="text" name="firstname"><br>
        <label for="lastname">lastname</label><br>
        <input type="text" name="lastname"><br>
        <label for="age">age</label><br>
        <input type="number" name="age"><br>
        
        <label for="departement">department</label><br>
        <input type="text" name="department"><br>
        <label for="gender">Gender</label><br>
        <input type="radio" name="gender" value="male">female <br>
        <input type="radio" name="gender" value="female">male <br>
        
        <input type="submit" name="submit">
    </form>
    
</body>
</html>
<?php
if($_SERVER['REQUEST_METHOD']=='POST'){

    include 'connection.php';
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $age=$_POST['age'];
    $dept=$_POST['department'];
    $gend=$_POST['gender'];

    $insert=mysqli_query($connection,"insert into addstudent values('','$fname','$lname','$age','$dept','$gend')");
}

?>