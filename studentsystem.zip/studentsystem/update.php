<?php
include 'connection.php';
$update=$_GET['student_id'];
$query=mysqli_query($connection,"select * from addstudent where student_id='$update'");
$row=mysqli_fetch_array($query);

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
        <label for="firstname">firstname</label><br>
        <input type="text" name="firstname" value="<?php echo $row['firstname']?>"><br>
        <label for="lastname">lastname</label><br>
        <input type="text" name="lastname"value="<?php echo $row['lastname']?>"><br>
        <label for="age">age</label><br>
        <input type="number" name="age"value="<?php echo $row['age']?>"><br>
        
        <label for="departement">department</label><br>
        <input type="text" name="department"value="<?php echo $row['department']?>"><br>
        <label for="gender">Gender</label><br>
        <input type="radio" name="gender" value="male">female <br>
        <input type="radio" name="gender" value="female">male <br>
        
        <input type="submit" name="submit">
    </form>
    
</body>
</html>

<?php 

if(isset($_POST['submit'])){
    $update=$_GET['student_id'];
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $age=$_POST['age'];
    $dept=$_POST['department'];
   
    $query=mysqli_query($connection,"update addstudent set firstname='$fname',lastname='$lname',age='$age',department='$dept' where student_id='$update'");
    if($query==1){
        echo "<script>alert('updated successful')</script>";
    }else{
        echo "<script>alert('failed')</script>";
    }
}
?>